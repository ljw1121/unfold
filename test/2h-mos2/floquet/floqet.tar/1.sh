for kk in {1..66};
do
cd ~/code/unfold/src
sed "s/asdfasdf/$kk/" bak.f90 > calc_spectrum.f90
make clean
make
cd ~/work/cdw/2h-mos2/3sqrt/wannier/cpl/job-0.00/2t
cp /home/jwlai/code/unfold/src/unfold.x .
./unfold.x > unfold.log
sed -i '1,52d' unfold.log
python readdata.py
cp ebs.png ebs-${kk}.png

done

